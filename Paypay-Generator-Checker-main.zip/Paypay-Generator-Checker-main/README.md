# 転売ヤーに注意

![:name](https://count.getloli.com/get/@:mizutama1233)

# Paypay-Generator-Checker
Paypayの送金リンクのジェネレーターとチェッカー

どっちも汚いコードですみません

## 現在webhookに送信するやつ使えない

main.pyよりももう片方の方がスレッドに対応しているので多分速い

なんかあったら

Discord: 
- [x] [https://discord.gg/3s9g8RFhMz](https://discord.gg/D5kzbK5S)
- [x] .kap210

にて連絡を

あとスターつけておいてね！！！
